import React, { createContext, useContext, useState } from 'react'

const GameContext = createContext()

export function GameProvider({ children }) {

  // Student info — now includes role: 'student' | 'admin'
  const [student, setStudent] = useState(null)

  const [lastResult, setLastResult] = useState(null)

  // ── Helper: is the current user an admin? ──
  const isAdmin = student?.role === 'admin'

  const value = {
    student,    setStudent,
    lastResult, setLastResult,
    isAdmin,
  }

  return (
    <GameContext.Provider value={value}>
      {children}
    </GameContext.Provider>
  )
}

export function useGame() {
  const context = useContext(GameContext)
  if (!context) throw new Error('useGame must be used inside a <GameProvider>')
  return context
}
