import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useGame } from '../context/GameContext';
import { registerStudent, loginStudent } from '../services/api';

export default function LoginPage() {
  const navigate    = useNavigate();
  const { setStudent } = useGame();

  const [isLogin,  setIsLogin]  = useState(true);
  const [formData, setFormData] = useState({ name: '', username: '', password: '' });
  const [error,    setError]    = useState('');
  const [loading,  setLoading]  = useState(false);

  const handleChange = (e) =>
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      let res;
      if (isLogin) {
        res = await loginStudent({ username: formData.username, password: formData.password });
      } else {
        res = await registerStudent({ name: formData.name, username: formData.username, password: formData.password });
      }

      localStorage.setItem('token', res.data.token);
      setStudent(res.data);   // includes role
      navigate('/map');
    } catch (err) {
      setError(err.response?.data?.message || 'Something went wrong.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-game-purple to-game-dark flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl p-8 w-full max-w-sm shadow-2xl">

        {/* Logo / title */}
        <div className="text-center mb-6">
          <div className="text-5xl mb-2">🏔️</div>
          <h1 className="text-3xl font-bold text-game-purple">Math Adventure</h1>
          <p className="text-gray-400 text-sm mt-1">
            {isLogin ? 'Welcome back! Login to play.' : 'Create your account and start playing!'}
          </p>
        </div>

        {/* Error */}
        {error && (
          <div className="bg-red-100 border border-red-300 text-red-700 p-3 rounded-lg mb-4 text-sm">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">

          {/* Name — only on register */}
          {!isLogin && (
            <div>
              <label className="block text-gray-600 font-semibold text-sm mb-1">Name</label>
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
                placeholder="Your full name"
                required
                className="w-full px-4 py-2.5 border border-gray-300 rounded-xl text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-game-purple"
              />
            </div>
          )}

          {/* Username */}
          <div>
            <label className="block text-gray-600 font-semibold text-sm mb-1">Username</label>
            <input
              type="text"
              name="username"
              value={formData.username}
              onChange={handleChange}
              placeholder="Enter username"
              required
              className="w-full px-4 py-2.5 border border-gray-300 rounded-xl text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-game-purple"
            />
          </div>

          {/* Password */}
          <div>
            <label className="block text-gray-600 font-semibold text-sm mb-1">Password</label>
            <input
              type="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              placeholder="Enter password"
              required
              className="w-full px-4 py-2.5 border border-gray-300 rounded-xl text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-game-purple"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-game-purple hover:bg-purple-700 text-white font-bold py-3 rounded-xl mt-2 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? 'Please wait…' : isLogin ? 'Login' : 'Create Account'}
          </button>
        </form>

        {/* Toggle login/register */}
        <p className="text-center text-gray-500 text-sm mt-5">
          {isLogin ? "Don't have an account? " : 'Already have an account? '}
          <button
            type="button"
            onClick={() => { setIsLogin(l => !l); setError(''); }}
            className="text-game-purple font-bold underline hover:text-purple-700"
          >
            {isLogin ? 'Register' : 'Login'}
          </button>
        </p>
      </div>
    </div>
  );
}
